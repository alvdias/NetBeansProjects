/**
 *
 * @author diego
 */
public class Calculadora {
    private CustoDAO custoDAO;
    
    public Calculadora(CustoDAO custoDAO) {
        this.custoDAO = custoDAO;
    }
    
    public int calcularFrete(String regiao, int peso) throws Exception {
        return 0;
    }
}

/**
 *
 * @author diego
 */
public class SimuladorDeEventos {
    public boolean status() {
        return true;
    }
    
    public boolean eventA() {
        return true;
    }
    
    public boolean eventB() {
        return true;
    }
    
    public boolean eventC() {
        return true;
    }
    
    public boolean eventD() {
        return true;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author diego
 */
public class CalculaHipoteca {
    public int calcularValorMaximoHipoteca(int genero, int idade, int salario) {
        return 0;
    }
}

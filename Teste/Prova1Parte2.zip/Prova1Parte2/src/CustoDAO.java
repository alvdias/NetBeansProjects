/**
 *
 * @author diego
 */
public interface CustoDAO {
    public int getCustoPorGrama(String regiao);
}

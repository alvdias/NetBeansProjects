package pilharestrita;

public class PilhaCheiaException extends Exception {
    
}

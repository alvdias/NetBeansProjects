package pilharestrita;

public class PilhaVaziaException extends Exception {

}
